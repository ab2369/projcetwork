const mongoose = require('mongoose')


const ProductSchema = new mongoose.Schema({
    
})